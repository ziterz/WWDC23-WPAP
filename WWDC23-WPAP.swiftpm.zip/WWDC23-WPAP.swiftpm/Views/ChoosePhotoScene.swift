//
//  ChoosePhotoScene.swift
//  WWDC23-WPAP
//
//  Created by Ziady Mubaraq on 09/04/23.
//

import SwiftUI

struct ChoosePhotoScene: View {
  
  // MARK: Screen Size
  let screenWidth = UIScreen.main.bounds.width
  let screenHeight = UIScreen.main.bounds.height
  
  // MARK: Properties
  @State var buttonOpacity: Double = 0.0
  
  // Controlling the page navigation
  @State var nextPage: Bool = false
  
  let dateFormatter: DateFormatter = {
          let formatter = DateFormatter()
          formatter.dateStyle = .short
          formatter.timeStyle = .none
          return formatter
      }()
  
  // MARK: View
  var body: some View {
    VStack(spacing: 0) {
      GeometryReader { geo in
        ZStack(alignment: .center) {
          VStack(alignment: .center, spacing: 0) {
            VStack {
              Image("wpap-step1")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: geo.size.width * (screenWidth < 1024 ? 0.80 : 0.70))
              Text("Photo: Ziady Mubaraq (Me)")
                .foregroundColor(Color.secondary)
                .frame(alignment: .leading)
                .font(.system(size: screenWidth * (screenWidth < 1024 ? 0.018 : 0.018), weight: .regular, design: .default))
                .padding(.top, 10)
            }
          }
          .frame(maxWidth: .infinity)
        }
        .frame(maxWidth: .infinity)
      }
      .frame(maxWidth: .infinity)
      .padding(.top, 50)
      
      Spacer()
      
      // Navigation Button
      if #available(iOS 16.0, *) {
        NavigationLink(
          destination: FacetingScene(),
          isActive: $nextPage) {
            HStack(alignment: .center, spacing: 0) {
              Button("Next Step") {
                self.nextPage = true
              }
              .padding(.horizontal,  screenWidth * (screenWidth < 1024 ? 0.038 : 0.035))
              .padding(.vertical, screenWidth * (screenWidth < 1024 ? 0.018 : 0.016))
              .background(RoundedRectangle(cornerRadius: 50)
                .fill(.black)
                .clipped(), alignment: .center)
              .font(.system(size: screenWidth * (screenWidth < 1024 ? 0.024 : 0.022), weight: .bold, design: .default))
              .foregroundColor(.white)
              .opacity(buttonOpacity)
              .onAppear {
                withAnimation(.easeIn(duration: 1)) {
                  self.buttonOpacity = 1.0
                }
              }
            }
          }
      }
    }
    .frame(maxWidth: .infinity)
    .padding(.horizontal, 50)
    .padding(.bottom, 50)
    .toolbar {
      ToolbarItem(placement: .principal) {
        Text("Step 1: Choose Photo")
          .font(.title2.bold())
          .accessibilityAddTraits(.isHeader)
      }
    }
  }
}

struct ChoosePhotoScene_Previews: PreviewProvider {
  static var previews: some View {
    ChoosePhotoScene()
  }
}
