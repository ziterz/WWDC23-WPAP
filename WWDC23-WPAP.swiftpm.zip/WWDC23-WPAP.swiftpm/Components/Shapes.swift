//
//  Shapes.swift
//  WWDC23-WPAP
//
//  Created by Ziady Mubaraq on 11/04/23.
//

import SwiftUI

//struct Shape1: Shape {
//  func path(in rect: CGRect) -> Path {
//    var path = Path()
//    let width = rect.size.width
//    let height = rect.size.height
//    path.move(to: CGPoint(x: 0.40138*width, y: 0.65567*height))
//    path.addLine(to: CGPoint(x: 0.40138*width, y: 0.99692*height))
//    path.addLine(to: CGPoint(x: 0.55889*width, y: 0.99647*height))
//    path.addLine(to: CGPoint(x: 0.85435*width, y: 0.93547*height))
//    path.addLine(to: CGPoint(x: 0.99394*width, y: 0.93547*height))
//    path.addLine(to: CGPoint(x: 0.99394*width, y: 0.55911*height))
//    path.addLine(to: CGPoint(x: 0.55889*width, y: 0.55911*height))
//    path.addLine(to: CGPoint(x: 0.88712*width, y: 0.34031*height))
//    path.addLine(to: CGPoint(x: 0.88712*width, y: 0.11977*height))
//    path.addLine(to: CGPoint(x: 0.00828*width, y: 0.00443*height))
//    path.addLine(to: CGPoint(x: 0.00456*width, y: 0.65567*height))
//    path.addLine(to: CGPoint(x: 0.40138*width, y: 0.65567*height))
//    path.closeSubpath()
//    return path
//  }
//}
//
//struct Shape2: Shape {
//  func path(in rect: CGRect) -> Path {
//    var path = Path()
//    let width = rect.size.width
//    let height = rect.size.height
//    path.move(to: CGPoint(x: 0.99853*width, y: 0.48493*height))
//    path.addLine(to: CGPoint(x: 0.99853*width, y: 0.22837*height))
//    path.addLine(to: CGPoint(x: 0.70901*width, y: 0.22837*height))
//    path.addLine(to: CGPoint(x: 0.46913*width, y: 0.41122*height))
//    path.addLine(to: CGPoint(x: 0.46913*width, y: 0.13901*height))
//    path.addLine(to: CGPoint(x: 0.19733*width, y: 0.13901*height))
//    path.addLine(to: CGPoint(x: 0.19792*width, y: 0.0027*height))
//    path.addLine(to: CGPoint(x: 0.00062*width, y: 0.35206*height))
//    path.addLine(to: CGPoint(x: 0.00062*width, y: 0.99174*height))
//    path.addLine(to: CGPoint(x: 0.77459*width, y: 0.35672*height))
//    path.addLine(to: CGPoint(x: 0.99853*width, y: 0.48493*height))
//    path.closeSubpath()
//    return path
//  }
//}
//
//struct Shape3: Shape {
//  func path(in rect: CGRect) -> Path {
//    var path = Path()
//    let width = rect.size.width
//    let height = rect.size.height
//    path.move(to: CGPoint(x: 0.95494*width, y: 0.94119*height))
//    path.addLine(to: CGPoint(x: 0.78095*width, y: 0.94119*height))
//    path.addLine(to: CGPoint(x: 0.24179*width, y: 0.78515*height))
//    path.addLine(to: CGPoint(x: 0.74631*width, y: 0.68643*height))
//    path.addLine(to: CGPoint(x: 0.97682*width, y: 0.68748*height))
//    path.addLine(to: CGPoint(x: 0.97682*width, y: 0.00183*height))
//    path.addLine(to: CGPoint(x: 0.48532*width, y: 0.03993*height))
//    path.addLine(to: CGPoint(x: 0.25064*width, y: 0.24696*height))
//    path.addLine(to: CGPoint(x: 0.60722*width, y: 0.40281*height))
//    path.addLine(to: CGPoint(x: 0.60722*width, y: 0.43963*height))
//    path.addLine(to: CGPoint(x: 0.02456*width, y: 0.59405*height))
//    path.addLine(to: CGPoint(x: 0.02456*width, y: 0.78863*height))
//    path.addLine(to: CGPoint(x: 0.48532*width, y: 0.94915*height))
//    path.addLine(to: CGPoint(x: 0.57492*width, y: 0.94915*height))
//    path.addLine(to: CGPoint(x: 0.63327*width, y: 0.9969*height))
//    path.addLine(to: CGPoint(x: 0.81403*width, y: 0.9969*height))
//    path.addLine(to: CGPoint(x: 0.95494*width, y: 0.94119*height))
//    path.closeSubpath()
//    return path
//  }
//}
//
//struct Shape4: Shape {
//  func path(in rect: CGRect) -> Path {
//    var path = Path()
//    let width = rect.size.width
//    let height = rect.size.height
//    path.move(to: CGPoint(x: 0.63709*width, y: 0.33586*height))
//    path.addLine(to: CGPoint(x: 0.91746*width, y: 0.45812*height))
//    path.addLine(to: CGPoint(x: 0.91746*width, y: 0.50479*height))
//    path.addLine(to: CGPoint(x: 0.42337*width, y: 0.50479*height))
//    path.addLine(to: CGPoint(x: 0.42337*width, y: 0.72105*height))
//    path.addLine(to: CGPoint(x: 0.76143*width, y: 0.90788*height))
//    path.addLine(to: CGPoint(x: 0.76143*width, y: 0.99878*height))
//    path.addLine(to: CGPoint(x: 0.76326*width, y: 0.99878*height))
//    path.addLine(to: CGPoint(x: 0.93107*width, y: 0.99878*height))
//    path.addLine(to: CGPoint(x: 0.93107*width, y: 0.94962*height))
//    path.addLine(to: CGPoint(x: 0.94102*width, y: 0.93725*height))
//    path.addLine(to: CGPoint(x: 0.94102*width, y: 0.84163*height))
//    path.addLine(to: CGPoint(x: 0.82583*width, y: 0.84163*height))
//    path.addLine(to: CGPoint(x: 0.87723*width, y: 0.77295*height))
//    path.addLine(to: CGPoint(x: 0.75919*width, y: 0.63508*height))
//    path.addLine(to: CGPoint(x: 0.99507*width, y: 0.63508*height))
//    path.addLine(to: CGPoint(x: 0.99507*width, y: 0.40402*height))
//    path.addLine(to: CGPoint(x: 0.6054*width, y: 0.23059*height))
//    path.addLine(to: CGPoint(x: 0.6054*width, y: 0.32047*height))
//    path.addLine(to: CGPoint(x: 0.46298*width, y: 0.25658*height))
//    path.addLine(to: CGPoint(x: 0.31752*width, y: 0.40402*height))
//    path.addLine(to: CGPoint(x: 0.20517*width, y: 0.40402*height))
//    path.addLine(to: CGPoint(x: 0.20517*width, y: 0.16074*height))
//    path.addLine(to: CGPoint(x: 0.4124*width, y: 0.16059*height))
//    path.addLine(to: CGPoint(x: 0.52921*width, y: 0.20292*height))
//    path.addLine(to: CGPoint(x: 0.52921*width, y: 0.00093*height))
//    path.addLine(to: CGPoint(x: 0.27993*width, y: 0.00093*height))
//    path.addLine(to: CGPoint(x: 0.20497*width, y: 0.00093*height))
//    path.addLine(to: CGPoint(x: 0.0018*width, y: 0.24671*height))
//    path.addLine(to: CGPoint(x: 0.13061*width, y: 0.4409*height))
//    path.addLine(to: CGPoint(x: 0.63709*width, y: 0.4409*height))
//    path.addLine(to: CGPoint(x: 0.63709*width, y: 0.33586*height))
//    path.closeSubpath()
//    return path
//  }
//}
//
//struct Shape5: Shape {
//  func path(in rect: CGRect) -> Path {
//    var path = Path()
//    let width = rect.size.width
//    let height = rect.size.height
//    path.move(to: CGPoint(x: 0.21009*width, y: 0.43633*height))
//    path.addLine(to: CGPoint(x: 0.21009*width, y: 0.65834*height))
//    path.addLine(to: CGPoint(x: 0.23896*width, y: 0.5789*height))
//    path.addLine(to: CGPoint(x: 0.23896*width, y: 0.77132*height))
//    path.addLine(to: CGPoint(x: 0.26569*width, y: 0.77132*height))
//    path.addLine(to: CGPoint(x: 0.26569*width, y: 0.99687*height))
//    path.addLine(to: CGPoint(x: 0.29718*width, y: 0.94088*height))
//    path.addLine(to: CGPoint(x: 0.37572*width, y: 0.94088*height))
//    path.addLine(to: CGPoint(x: 0.42213*width, y: 0.81862*height))
//    path.addLine(to: CGPoint(x: 0.3275*width, y: 0.81862*height))
//    path.addLine(to: CGPoint(x: 0.3275*width, y: 0.47142*height))
//    path.addLine(to: CGPoint(x: 0.55343*width, y: 0.47142*height))
//    path.addLine(to: CGPoint(x: 0.55343*width, y: 0.5932*height))
//    path.addLine(to: CGPoint(x: 0.70062*width, y: 0.33971*height))
//    path.addLine(to: CGPoint(x: 0.76521*width, y: 0.35448*height))
//    path.addLine(to: CGPoint(x: 0.70062*width, y: 0.46586*height))
//    path.addLine(to: CGPoint(x: 0.72382*width, y: 0.5704*height))
//    path.addLine(to: CGPoint(x: 0.89801*width, y: 0.65137*height))
//    path.addLine(to: CGPoint(x: 0.99515*width, y: 0.65137*height))
//    path.addLine(to: CGPoint(x: 0.99515*width, y: 0.00172*height))
//    path.addLine(to: CGPoint(x: 0.79702*width, y: 0.00172*height))
//    path.addLine(to: CGPoint(x: 0.79702*width, y: 0.05576*height))
//    path.addLine(to: CGPoint(x: 0.70944*width, y: 0.26672*height))
//    path.addLine(to: CGPoint(x: 0.55012*width, y: 0.37716*height))
//    path.addLine(to: CGPoint(x: 0.34696*width, y: 0.37716*height))
//    path.addLine(to: CGPoint(x: 0.16133*width, y: 0.23323*height))
//    path.addLine(to: CGPoint(x: 0.14165*width, y: 0.18982*height))
//    path.addLine(to: CGPoint(x: 0.00265*width, y: 0.19089*height))
//    path.addLine(to: CGPoint(x: 0.00265*width, y: 0.21138*height))
//    path.addLine(to: CGPoint(x: 0.21009*width, y: 0.43633*height))
//    path.closeSubpath()
//    path.move(to: CGPoint(x: 0.94094*width, y: 0.56762*height))
//    path.addLine(to: CGPoint(x: 0.88587*width, y: 0.56762*height))
//    path.addLine(to: CGPoint(x: 0.88101*width, y: 0.47142*height))
//    path.addLine(to: CGPoint(x: 0.94094*width, y: 0.47142*height))
//    path.addLine(to: CGPoint(x: 0.94094*width, y: 0.56762*height))
//    path.closeSubpath()
//    path.move(to: CGPoint(x: 0.94094*width, y: 0.06562*height))
//    path.addLine(to: CGPoint(x: 0.94094*width, y: 0.4521*height))
//    path.addLine(to: CGPoint(x: 0.87817*width, y: 0.4521*height))
//    path.addLine(to: CGPoint(x: 0.84701*width, y: 0.06562*height))
//    path.addLine(to: CGPoint(x: 0.94094*width, y: 0.06562*height))
//    path.closeSubpath()
//    return path
//  }
//}
//
//struct Shape6: Shape {
//    func path(in rect: CGRect) -> Path {
//        var path = Path()
//        let width = rect.size.width
//        let height = rect.size.height
//        path.move(to: CGPoint(x: 0.43569*width, y: 0.31384*height))
//        path.addLine(to: CGPoint(x: 0.00727*width, y: 0.40168*height))
//        path.addLine(to: CGPoint(x: 0.01154*width, y: 0.99492*height))
//        path.addLine(to: CGPoint(x: 0.47739*width, y: 0.99492*height))
//        path.addLine(to: CGPoint(x: 0.51909*width, y: 0.78865*height))
//        path.addLine(to: CGPoint(x: 0.3628*width, y: 0.78865*height))
//        path.addLine(to: CGPoint(x: 0.85004*width, y: 0.56063*height))
//        path.addLine(to: CGPoint(x: 0.99492*width, y: 0.22613*height))
//        path.addLine(to: CGPoint(x: 0.81065*width, y: 0.00432*height))
//        path.addLine(to: CGPoint(x: 0.43569*width, y: 0.31384*height))
//        path.closeSubpath()
//        return path
//    }
//}
//
//struct Shape7: Shape {
//    func path(in rect: CGRect) -> Path {
//        var path = Path()
//        let width = rect.size.width
//        let height = rect.size.height
//        path.move(to: CGPoint(x: 0.04899*width, y: 0.90504*height))
//        path.addLine(to: CGPoint(x: 0.04899*width, y: 0.81508*height))
//        path.addLine(to: CGPoint(x: 0.1952*width, y: 0.81508*height))
//        path.addLine(to: CGPoint(x: 0.1952*width, y: 0.93032*height))
//        path.addLine(to: CGPoint(x: 0.07294*width, y: 0.93032*height))
//        path.addLine(to: CGPoint(x: 0.13364*width, y: 0.99972*height))
//        path.addLine(to: CGPoint(x: 0.35946*width, y: 0.91408*height))
//        path.addLine(to: CGPoint(x: 0.35946*width, y: 0.73721*height))
//        path.addLine(to: CGPoint(x: 0.59697*width, y: 0.7761*height))
//        path.addLine(to: CGPoint(x: 0.7097*width, y: 0.52715*height))
//        path.addLine(to: CGPoint(x: 0.53621*width, y: 0.34294*height))
//        path.addLine(to: CGPoint(x: 0.58546*width, y: 0.30075*height))
//        path.addLine(to: CGPoint(x: 0.84034*width, y: 0.50197*height))
//        path.addLine(to: CGPoint(x: 0.99493*width, y: 0.41876*height))
//        path.addLine(to: CGPoint(x: 0.99493*width, y: 0.3755*height))
//        path.addLine(to: CGPoint(x: 0.81362*width, y: 0.3755*height))
//        path.addLine(to: CGPoint(x: 0.81362*width, y: 0.21628*height))
//        path.addLine(to: CGPoint(x: 0.99493*width, y: 0.21628*height))
//        path.addLine(to: CGPoint(x: 0.99493*width, y: 0.1965*height))
//        path.addLine(to: CGPoint(x: 0.67479*width, y: 0.00427*height))
//        path.addLine(to: CGPoint(x: 0.49071*width, y: 0.04938*height))
//        path.addLine(to: CGPoint(x: 0.46326*width, y: 0.11217*height))
//        path.addLine(to: CGPoint(x: 0.68002*width, y: 0.28326*height))
//        path.addLine(to: CGPoint(x: 0.66383*width, y: 0.29604*height))
//        path.addLine(to: CGPoint(x: 0.45261*width, y: 0.13652*height))
//        path.addLine(to: CGPoint(x: 0.40335*width, y: 0.24977*height))
//        path.addLine(to: CGPoint(x: 0.25061*width, y: 0.24977*height))
//        path.addLine(to: CGPoint(x: 0.25061*width, y: 0.30775*height))
//        path.addLine(to: CGPoint(x: 0.40064*width, y: 0.49079*height))
//        path.addLine(to: CGPoint(x: 0.37768*width, y: 0.50338*height))
//        path.addLine(to: CGPoint(x: 0.34105*width, y: 0.45833*height))
//        path.addLine(to: CGPoint(x: 0.27333*width, y: 0.45833*height))
//        path.addLine(to: CGPoint(x: 0.16356*width, y: 0.52729*height))
//        path.addLine(to: CGPoint(x: 0.16356*width, y: 0.70499*height))
//        path.addLine(to: CGPoint(x: 0.09042*width, y: 0.609*height))
//        path.addLine(to: CGPoint(x: 0.07035*width, y: 0.61983*height))
//        path.addLine(to: CGPoint(x: 0.00097*width, y: 0.85133*height))
//        path.addLine(to: CGPoint(x: 0.04899*width, y: 0.90504*height))
//        path.closeSubpath()
//        path.move(to: CGPoint(x: 0.4683*width, y: 0.46455*height))
//        path.addLine(to: CGPoint(x: 0.62659*width, y: 0.46455*height))
//        path.addLine(to: CGPoint(x: 0.62659*width, y: 0.58951*height))
//        path.addLine(to: CGPoint(x: 0.4683*width, y: 0.58951*height))
//        path.addLine(to: CGPoint(x: 0.4683*width, y: 0.46455*height))
//        path.closeSubpath()
//        path.move(to: CGPoint(x: 0.39443*width, y: 0.6106*height))
//        path.addLine(to: CGPoint(x: 0.49909*width, y: 0.6106*height))
//        path.addLine(to: CGPoint(x: 0.49909*width, y: 0.70475*height))
//        path.addLine(to: CGPoint(x: 0.39443*width, y: 0.70475*height))
//        path.addLine(to: CGPoint(x: 0.39443*width, y: 0.6106*height))
//        path.closeSubpath()
//        return path
//    }
//}
//
//struct Shape8: Shape {
//    func path(in rect: CGRect) -> Path {
//        var path = Path()
//        let width = rect.size.width
//        let height = rect.size.height
//        path.move(to: CGPoint(x: 0.00405*width, y: 0.74075*height))
//        path.addLine(to: CGPoint(x: 0.00405*width, y: 0.08784*height))
//        path.addLine(to: CGPoint(x: 0.37971*width, y: 0.00736*height))
//        path.addLine(to: CGPoint(x: 0.99391*width, y: height))
//        path.addLine(to: CGPoint(x: 0.26626*width, y: height))
//        path.addLine(to: CGPoint(x: 0.26626*width, y: 0.74075*height))
//        path.addLine(to: CGPoint(x: 0.00405*width, y: 0.74075*height))
//        path.closeSubpath()
//        return path
//    }
//}
//
//struct Shape9: Shape {
//    func path(in rect: CGRect) -> Path {
//        var path = Path()
//        let width = rect.size.width
//        let height = rect.size.height
//        path.move(to: CGPoint(x: 0.27324*width, y: 0.45734*height))
//        path.addLine(to: CGPoint(x: 0.27324*width, y: 0.62906*height))
//        path.addLine(to: CGPoint(x: 0.66095*width, y: 0.73206*height))
//        path.addLine(to: CGPoint(x: 0.66095*width, y: 0.99823*height))
//        path.addLine(to: CGPoint(x: 0.99181*width, y: 0.99823*height))
//        path.addLine(to: CGPoint(x: 0.99181*width, y: 0.88166*height))
//        path.addLine(to: CGPoint(x: 0.7722*width, y: 0.88166*height))
//        path.addLine(to: CGPoint(x: 0.94537*width, y: 0.4837*height))
//        path.addLine(to: CGPoint(x: 0.99181*width, y: 0.51096*height))
//        path.addLine(to: CGPoint(x: 0.12788*width, y: 0.00389*height))
//        path.addLine(to: CGPoint(x: 0.00792*width, y: 0.00389*height))
//        path.addLine(to: CGPoint(x: 0.70932*width, y: 0.54535*height))
//        path.addLine(to: CGPoint(x: 0.27324*width, y: 0.45734*height))
//        path.closeSubpath()
//        return path
//    }
//}

struct Shape1: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.00889*width, y: 0.09321*height))
        path.addLine(to: CGPoint(x: 0.5182*width, y: 0.22265*height))
        path.addLine(to: CGPoint(x: 0.5182*width, y: 0.71224*height))
        path.addLine(to: CGPoint(x: 0.73873*width, y: 0.86692*height))
        path.addLine(to: CGPoint(x: 0.73873*width, y: 0.99495*height))
        path.addLine(to: CGPoint(x: 0.99293*width, y: 0.99495*height))
        path.addLine(to: CGPoint(x: 0.99293*width, y: 0.72613*height))
        path.addLine(to: CGPoint(x: 0.99293*width, y: 0.54055*height))
        path.addLine(to: CGPoint(x: 0.5182*width, y: 0.00695*height))
        path.addLine(to: CGPoint(x: 0.00889*width, y: 0.09321*height))
        path.closeSubpath()
        return path
    }
}

struct Shape2: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.7809*width, y: 0.09954*height))
        path.addLine(to: CGPoint(x: 0.65187*width, y: 0.09954*height))
        path.addLine(to: CGPoint(x: 0.65128*width, y: 0.09894*height))
        path.addLine(to: CGPoint(x: 0.81969*width, y: 0.0019*height))
        path.addLine(to: CGPoint(x: 0.81972*width, y: 0.0019*height))
        path.addLine(to: CGPoint(x: 0.90176*width, y: 0.07652*height))
        path.addLine(to: CGPoint(x: 0.99367*width, y: 0.07652*height))
        path.addLine(to: CGPoint(x: 0.90944*width, y: 0.0019*height))
        path.addLine(to: CGPoint(x: 0.99702*width, y: 0.0019*height))
        path.addLine(to: CGPoint(x: 0.99702*width, y: 0.817*height))
        path.addLine(to: CGPoint(x: 0.99367*width, y: 0.99846*height))
        path.addLine(to: CGPoint(x: 0.8065*width, y: 0.99846*height))
        path.addLine(to: CGPoint(x: 0.8065*width, y: 0.35619*height))
        path.addLine(to: CGPoint(x: 0.37995*width, y: 0.35713*height))
        path.addLine(to: CGPoint(x: 0.37995*width, y: 0.73212*height))
        path.addLine(to: CGPoint(x: 0.33109*width, y: 0.69865*height))
        path.addLine(to: CGPoint(x: 0.33109*width, y: 0.74369*height))
        path.addLine(to: CGPoint(x: 0.00886*width, y: 0.70666*height))
        path.addLine(to: CGPoint(x: 0.00886*width, y: 0.46909*height))
        path.addLine(to: CGPoint(x: 0.59441*width, y: 0.13171*height))
        path.addLine(to: CGPoint(x: 0.59485*width, y: 0.13213*height))
        path.addLine(to: CGPoint(x: 0.82607*width, y: 0.13032*height))
        path.addLine(to: CGPoint(x: 0.7809*width, y: 0.09954*height))
        path.closeSubpath()
        return path
    }
}

struct Shape3: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.77939*width, y: 0.2059*height))
        path.addLine(to: CGPoint(x: 0.99765*width, y: 0.00093*height))
        path.addLine(to: CGPoint(x: 0.17979*width, y: 0.00093*height))
        path.addLine(to: CGPoint(x: 0.01239*width, y: 0.59109*height))
        path.addLine(to: CGPoint(x: 0.00355*width, y: 0.99609*height))
        path.addLine(to: CGPoint(x: 0.05629*width, y: 0.99609*height))
        path.addLine(to: CGPoint(x: 0.13468*width, y: 0.87196*height))
        path.addLine(to: CGPoint(x: 0.19748*width, y: 0.83427*height))
        path.addLine(to: CGPoint(x: 0.19748*width, y: 0.70976*height))
        path.addLine(to: CGPoint(x: 0.3714*width, y: 0.54039*height))
        path.addLine(to: CGPoint(x: 0.57849*width, y: 0.2059*height))
        path.addLine(to: CGPoint(x: 0.77939*width, y: 0.2059*height))
        path.closeSubpath()
        return path
    }
}

struct Shape4: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.81918*width, y: 0.0044*height))
        path.addLine(to: CGPoint(x: 0.42325*width, y: 0.01041*height))
        path.addLine(to: CGPoint(x: 0.00502*width, y: 0.01041*height))
        path.addLine(to: CGPoint(x: 0.00502*width, y: 0.29531*height))
        path.addLine(to: CGPoint(x: 0.2723*width, y: 0.89743*height))
        path.addLine(to: CGPoint(x: 0.42128*width, y: 0.93949*height))
        path.addLine(to: CGPoint(x: 0.63558*width, y: 0.99999*height))
        path.addLine(to: CGPoint(x: 0.99269*width, y: 0.90344*height))
        path.addLine(to: CGPoint(x: 0.99269*width, y: 0.2607*height))
        path.addLine(to: CGPoint(x: 0.81918*width, y: 0.0044*height))
        path.closeSubpath()
        return path
    }
}

struct Shape5: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.41605*width, y: 0.99503*height))
        path.addLine(to: CGPoint(x: 0.00725*width, y: 0.00464*height))
        path.addLine(to: CGPoint(x: 0.79849*width, y: 0.09335*height))
        path.addLine(to: CGPoint(x: 0.98622*width, y: 0.06706*height))
        path.addLine(to: CGPoint(x: 0.98621*width, y: 0.66795*height))
        path.addLine(to: CGPoint(x: 0.98621*width, y: 0.99503*height))
        path.addLine(to: CGPoint(x: 0.41605*width, y: 0.99503*height))
        path.closeSubpath()
        return path
    }
}

struct Shape6: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.49891*width, y: 0.15931*height))
        path.addLine(to: CGPoint(x: 0.01756*width, y: 0.31377*height))
        path.addLine(to: CGPoint(x: 0.01756*width, y: 0.99844*height))
        path.addLine(to: CGPoint(x: 0.24194*width, y: 0.91956*height))
        path.addLine(to: CGPoint(x: 0.51569*width, y: 0.74321*height))
        path.addLine(to: CGPoint(x: 0.77032*width, y: 0.5061*height))
        path.addLine(to: CGPoint(x: 0.88134*width, y: 0.24134*height))
        path.addLine(to: CGPoint(x: 0.98065*width, y: 0.00477*height))
        path.addLine(to: CGPoint(x: 0.49891*width, y: 0.15931*height))
        path.closeSubpath()
        return path
    }
}

struct Shape7: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.34153*width, y: 0.41483*height))
        path.addLine(to: CGPoint(x: 0.8679*width, y: 0.41483*height))
        path.addLine(to: CGPoint(x: 0.99553*width, y: 0.24484*height))
        path.addLine(to: CGPoint(x: 0.55478*width, y: 0.24484*height))
        path.addLine(to: CGPoint(x: 0.34153*width, y: 0.14694*height))
        path.addLine(to: CGPoint(x: 0.34153*width, y: 0.0578*height))
        path.addLine(to: CGPoint(x: 0.2123*width, y: 0.109*height))
        path.addLine(to: CGPoint(x: 0.10706*width, y: 0.14694*height))
        path.addLine(to: CGPoint(x: 0.0034*width, y: 0.00881*height))
        path.addLine(to: CGPoint(x: 0.0034*width, y: 0.20192*height))
        path.addLine(to: CGPoint(x: 0.08391*width, y: 0.47008*height))
        path.addLine(to: CGPoint(x: 0.38776*width, y: 0.89111*height))
        path.addLine(to: CGPoint(x: 0.51049*width, y: 0.9949*height))
        path.addLine(to: CGPoint(x: 0.51049*width, y: 0.93144*height))
        path.addLine(to: CGPoint(x: 0.2454*width, y: 0.5782*height))
        path.addLine(to: CGPoint(x: 0.2454*width, y: 0.41483*height))
        path.addLine(to: CGPoint(x: 0.34153*width, y: 0.41483*height))
        path.closeSubpath()
        return path
    }
}

struct Shape8: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.98395*width, y: 0.94336*height))
        path.addLine(to: CGPoint(x: 0.98202*width, y: 0.00281*height))
        path.addLine(to: CGPoint(x: 0.01437*width, y: 0.22326*height))
        path.addLine(to: CGPoint(x: 0.01469*width, y: 0.99985*height))
        path.addLine(to: CGPoint(x: 0.01469*width, y: 0.67699*height))
        path.addLine(to: CGPoint(x: 0.36795*width, y: 0.79151*height))
        path.addLine(to: CGPoint(x: 0.36795*width, y: 0.99985*height))
        path.addLine(to: CGPoint(x: 0.82634*width, y: 0.99985*height))
        path.addLine(to: CGPoint(x: 0.98395*width, y: 0.94336*height))
        path.closeSubpath()
        return path
    }
}
