//
//  WelcomeView.swift
//  WWDC23-WPAP
//
//  Created by Ziady Mubaraq on 13/04/23.
//

import SwiftUI

@main
struct MyApp: App {
  
  // MARK: View
  var body: some Scene {
    WindowGroup {
      
      // Only compatible with iOS 16++
      if #available(iOS 16.0, *) {
        NavigationStack {
          WelcomeScene()
        }
      }
    }
  }
}
